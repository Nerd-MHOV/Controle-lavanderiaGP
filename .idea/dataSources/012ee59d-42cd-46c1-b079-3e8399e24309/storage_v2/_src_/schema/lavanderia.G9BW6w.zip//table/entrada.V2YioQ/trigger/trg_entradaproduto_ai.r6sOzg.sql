create definer = root@localhost trigger TRG_EntradaProduto_AI
    after insert
    on entrada
    for each row
BEGIN
      CALL SP_AtualizaEstoque (new.id_produto, new.qtde, new.id_departamento);
END;

