create definer = root@localhost trigger TRG_EntradaProduto_AD
    after delete
    on entrada
    for each row
BEGIN
      CALL SP_AtualizaEstoque (old.id_produto, old.qtde * -1, old.id_departamento);
END;

