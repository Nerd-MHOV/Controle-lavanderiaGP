create
    definer = root@localhost procedure SP_AtualizaEstoque(IN id_prod int, IN qtde_comprada int, IN id_depart int)
BEGIN
    declare contador int(11);

    SELECT count(*) into contador FROM estoque WHERE id_produto = id_prod;

    IF contador > 0 THEN
        UPDATE estoque SET qtde=qtde + qtde_comprada
        WHERE id_produto = id_prod;
    ELSE
        INSERT INTO estoque (id_produto, qtde, id_departamento) values (id_prod, qtde_comprada, id_depart);
    END IF;
END;

