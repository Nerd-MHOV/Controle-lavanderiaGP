create definer = phpmyadmin@localhost trigger TRG_EntradaProduto_AU
    after update
    on entrada
    for each row
BEGIN
      CALL SP_AtualizaEstoque (new.id_produto, new.qtde - old.qtde, new.id_departamento);
END;

