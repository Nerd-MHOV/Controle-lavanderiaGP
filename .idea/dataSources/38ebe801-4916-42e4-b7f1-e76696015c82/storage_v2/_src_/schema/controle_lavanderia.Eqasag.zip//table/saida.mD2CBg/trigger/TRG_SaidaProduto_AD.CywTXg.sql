create definer = phpmyadmin@localhost trigger TRG_SaidaProduto_AD
    after delete
    on saida
    for each row
BEGIN
      CALL SP_AtualizaEstoque (old.id_produto, old.qtde, old.id_departamento);
END;

